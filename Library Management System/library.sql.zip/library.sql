-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 27, 2016 at 09:09 AM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 5.6.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `library`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_information`
--

CREATE TABLE `admin_information` (
  `First_Name` varchar(100) NOT NULL,
  `Last_Name` varchar(100) NOT NULL,
  `User_Name` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `Confirm_Password` varchar(100) NOT NULL,
  `Email_ID` varchar(100) NOT NULL,
  `Contact_No` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_information`
--

INSERT INTO `admin_information` (`First_Name`, `Last_Name`, `User_Name`, `Password`, `Confirm_Password`, `Email_ID`, `Contact_No`) VALUES
('12', '1', '123', '123', '123', '1', '1'),
('Admin', '', 'Admin', 'Password', 'Password', 'admin@library.com', '01XXXXXXXXX');

-- --------------------------------------------------------

--
-- Table structure for table `bookshelf`
--

CREATE TABLE `bookshelf` (
  `Book_ID` varchar(100) NOT NULL,
  `Book_Name` varchar(100) NOT NULL,
  `Author_Name` varchar(100) NOT NULL,
  `Shelf_No` varchar(100) NOT NULL,
  `Total_Copy` int(255) NOT NULL,
  `Available_Copy` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bookshelf`
--

INSERT INTO `bookshelf` (`Book_ID`, `Book_Name`, `Author_Name`, `Shelf_No`, `Total_Copy`, `Available_Copy`) VALUES
('CS111', 'Java', 'Hertbart', '3C', 50, 50),
('CS123', 'Java: How to Program', 'Paul Dietel', '1A', 50, 49),
('CS124', 'Thoery Of Computation', 'Michael Sipser', '3C', 70, 70),
('CS125', 'Computer Organization & Architecture', 'Charlse Murat', '3C', 60, 58),
('CS126', 'Algorithms', 'Thomas H. Corman', '4D', 80, 79),
('CS127', 'Data Structure', 'Niklaus Wirth', '5E', 65, 65),
('CS128', 'C++', 'Sabbir Ahmed', '5E', 40, 40);

-- --------------------------------------------------------

--
-- Table structure for table `issue_books`
--

CREATE TABLE `issue_books` (
  `User_Name` varchar(100) NOT NULL,
  `Book_ID` varchar(100) NOT NULL,
  `Borrow_Date` date NOT NULL,
  `Return_Date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `issue_books`
--

INSERT INTO `issue_books` (`User_Name`, `Book_ID`, `Borrow_Date`, `Return_Date`) VALUES
('Mahid', 'CS123', '2016-12-27', '2017-01-03'),
('Jahid', 'CS124', '2016-12-27', '2017-01-03'),
('Jahid', 'CS125', '2016-12-27', '2017-01-03'),
('Jahid', 'CS126', '2016-12-27', '2017-01-03'),
('Ashik', 'CS124', '2016-12-27', '2017-01-03'),
('Ashik', 'CS125', '2016-12-27', '2017-01-03');

-- --------------------------------------------------------

--
-- Table structure for table `librarian_information`
--

CREATE TABLE `librarian_information` (
  `First_Name` varchar(50) NOT NULL,
  `Last_Name` varchar(50) NOT NULL,
  `User_Name` varchar(50) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `Confirm_Password` varchar(100) NOT NULL,
  `Email_ID` varchar(100) NOT NULL,
  `Contact_No` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `librarian_information`
--

INSERT INTO `librarian_information` (`First_Name`, `Last_Name`, `User_Name`, `Password`, `Confirm_Password`, `Email_ID`, `Contact_No`) VALUES
('Jame', 'Ahmed', 'Arwin', '123456', '123456', 'jameahmed125@yahoo.com', '01750680929'),
('Badhon', 'Noyon', 'Pathik', '123456', '123456', 'pathik@gmail.com', '017XXXXXXXX'),
('Muhtasim', 'Ibtida', 'Shouvik', '123456', '123456', 'shouvik@gmail.com', '017XXXXXXXX');

-- --------------------------------------------------------

--
-- Table structure for table `user_information`
--

CREATE TABLE `user_information` (
  `First_Name` varchar(50) NOT NULL,
  `Last_Name` varchar(50) NOT NULL,
  `User_Name` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `Confirm_Password` varchar(100) NOT NULL,
  `Email_ID` varchar(100) NOT NULL,
  `Contact_No` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_information`
--

INSERT INTO `user_information` (`First_Name`, `Last_Name`, `User_Name`, `Password`, `Confirm_Password`, `Email_ID`, `Contact_No`) VALUES
('a', 'a', 'a', 'a', 'a', 'a', 'a'),
('Ashik', 'Ahmed', 'Ashik', '123456', '123456', 'ashik@yahoo.com', '01XXXXXXXXX'),
('Jahid', 'Hasan', 'Jahid', '123456', '123456', 'jahid@yahoo.com', '01XXXXXXXXX'),
('Mahid', 'Shahriar', 'Mahid', '123456', '123456', 'mahid@yahoo.com', '01XXXXXXXXX'),
('Touhid', 'Islam', 'Touhid', '123456', '123456', 'touhid@yahoo.com', '01XXXXXXXXX');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_information`
--
ALTER TABLE `admin_information`
  ADD UNIQUE KEY `User_Name` (`User_Name`);

--
-- Indexes for table `bookshelf`
--
ALTER TABLE `bookshelf`
  ADD UNIQUE KEY `Book_ID` (`Book_ID`);

--
-- Indexes for table `librarian_information`
--
ALTER TABLE `librarian_information`
  ADD UNIQUE KEY `User_Name` (`User_Name`);

--
-- Indexes for table `user_information`
--
ALTER TABLE `user_information`
  ADD UNIQUE KEY `User Name` (`User_Name`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
